package FactoryPattern;

public abstract class Computer_factory {

    public abstract Computer get_pc();

//    public String do_something(){
//        Computer c=this.get_pc();
//        return c.get_build_notofication();
//    }
}

