package Abs_factory;

public class PMScrollBar extends ScrollBar {
    @Override
    public void show_scrollBar() {
        System.out.println("This is  Scrollbar of PM");
    }
}
