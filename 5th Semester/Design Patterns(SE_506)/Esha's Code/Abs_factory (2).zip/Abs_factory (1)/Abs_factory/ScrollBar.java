package Abs_factory;

public abstract class ScrollBar {
    public abstract void show_scrollBar();
}
