package Abs_factory;

public class PMWindow extends Window{
    @Override
    public void show_window() {
        System.out.println("This is PM's Window");
    }
}
