package Abs_factory;

public class MotifScrollBar extends ScrollBar{
    @Override
    public void show_scrollBar() {
        System.out.println("This is Scrollbar of Motif");
    }
}
