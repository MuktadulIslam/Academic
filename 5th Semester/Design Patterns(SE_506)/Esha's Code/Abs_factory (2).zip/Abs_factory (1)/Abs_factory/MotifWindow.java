package Abs_factory;

public class MotifWindow extends Window{
    @Override
    public void show_window() {
        System.out.println("This is Motif's Window");
    }
}
