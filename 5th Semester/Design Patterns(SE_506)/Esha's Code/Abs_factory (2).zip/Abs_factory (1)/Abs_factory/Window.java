package Abs_factory;

public abstract class Window {

    public abstract void show_window();
}
