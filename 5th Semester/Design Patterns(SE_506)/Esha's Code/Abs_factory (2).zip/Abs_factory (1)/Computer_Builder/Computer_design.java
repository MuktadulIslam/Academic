package Computer_Builder;

interface Computer_design {

    public void set_ram(String ram);
    public void set_hdd(String hdd);
    public void set_cpu(String cpu);
    public void set_monitor(String monitor);

}
